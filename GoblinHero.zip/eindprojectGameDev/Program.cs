﻿
using var game = new eindprojectGameDev.Game1();
game.Run();
