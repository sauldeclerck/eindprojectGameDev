﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eindprojectGameDev
{
    abstract class GlobalSettings
    {
        public static int Height = 1080;
        public static int Width = 1920;
    }
}
