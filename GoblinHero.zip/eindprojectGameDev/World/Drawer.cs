﻿using eindprojectGameDev.interfaces;
using eindprojectGameDev.Map;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eindprojectGameDev.World
{
    internal class Drawer
    {
        Level1 level1 = null;
        Level2 level2 = null;
        GameStates previousState = GameStates.menu;
        Start start = null;
        public Drawer()
        {
            start = new Start();
        }

        public void Update(GameTime gameTime)
        {
            if (previousState != GameState.gameState)
            {
                switch (previousState)
                {
                    case GameStates.menu:
                        start = null;
                        break;
                    case GameStates.level1:
                        level1 = null;
                        break;
                    case GameStates.level2:
                        break;
                    case GameStates.gameover:
                        break;
                    case GameStates.exit:
                        break;
                    default:
                        break;
                }
                switch (GameState.gameState)
                {
                    case GameStates.menu:
                        start = new Start();
                        break;
                    case GameStates.level1:
                        level1 = new Level1();
                        //LevelManager.Initialize();
                        break;
                    case GameStates.level2:
                        break;
                    case GameStates.gameover:
                        break;
                    case GameStates.exit:
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (previousState)
                {
                    case GameStates.menu:
                        start.Update(gameTime);
                        break;
                    case GameStates.level1:
                        if (!LevelManager.initialized)
                        {
                            LevelManager.Initialize();
                            level1 = new Level1();
                        }
                        LevelManager.Update(gameTime);
                        break;
                    case GameStates.level2:
                        break;
                    case GameStates.gameover:
                        break;
                    case GameStates.exit:
                        break;
                    default:
                        break;
                }
            }
            previousState = GameState.gameState;
        }
        
        public void Draw(SpriteBatch spriteBatch)
        {
            switch (GameState.gameState)
            {
                case GameStates.menu:
                    start.Draw(spriteBatch);
                    break;
                case GameStates.level1:
                    LevelManager.Draw(spriteBatch);
                    break;
                case GameStates.level2:
                    break;
                case GameStates.gameover:
                    break;
                case GameStates.exit:
                    break;
                default:
                    break;
            }
        }

    }
}
